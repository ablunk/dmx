#include <odemx/odemx.h>
#include <iostream>
#include <sstream>

#define print(MSG) std::cout << getLabel() << ": " << MSG << std::endl;

int num = 5;

class Counter : public odemx::base::Process {
public:
    Counter(odemx::base::Simulation& sim)
        : odemx::base::Process (sim, "A simple process")
        {}

    virtual int main();
};

int Counter::main() {
    while (num > 0) {
        num--;
        hold();
    }
    return 0;
}

int main(int argc, char *argv[]) {
    if (argc > 1) {
        std::stringstream str;
        str << argv[1];
        str >> num;
    }

    odemx::base::Simulation& sim = odemx::getDefaultSimulation();

    Counter c1(sim);
    c1.activate();
    Counter c2(sim);
    c2.activate();

    std::cout << "initial count = " << num << std::endl;
    sim.run();
    std::cout << "final count = " << num << std::endl;

    return 0;
}
