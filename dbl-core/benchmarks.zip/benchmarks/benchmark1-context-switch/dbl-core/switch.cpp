/*
 * DBL Core
 * Copyright (C) 2013 Andreas Blunk
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <iostream>
#include <sstream>

//#define PRINT_MEM_USAGE
//#define PRINT_LOG

#include "goto-sim.cpp"

int count = 3;

class P : public Execution {
public:
    int n;

    P(int pid, void* cont) : Execution(pid,cont), n(0) {}
};


void simulate(int argc, char *argv[]) {
    int nextPid = 0; // next available pid
    Execution* cx; // current execution
    ml = new MovingList();

    // main Execution gets pid-0
    cx = new Execution(nextPid++, &&main_l1);
    ml->last->add(cx);

    // beginning of main
    main_l1:;

    if (argc > 1) {
        std::stringstream str;
        str << argv[1];
        str >> count;
    }

    ml->last->add(new P(nextPid++, &&P_actions));
    log("P created.");
    ml->last->add(new P(nextPid++, &&P_actions));
    log("P created.");

    //print("initial count = " << count);
  
    while (count > 0) {
        count--;
        cx->cont = &&main_l2;
        YIELD;
        main_l2:;
    }
    //print("final count = " << count);
    //std::cout << count << std::endl;

    goto end_cp;

    P_actions:;
    log("action execution begins.");

    while (count > 0) {
        count--;
        cx->cont = &&P_actions_l1;
        YIELD;
        P_actions_l1:;
    }

    TERMINATE;

    // end of program
    end_cp:;
    //print("reached end_cp");
}

int main(int argc, char *argv[]) {
    simulate(argc, argv);

#ifdef PRINT_MEM_USAGE
    printMemUsage();
#endif

    return 0;
}
