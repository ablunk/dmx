#include "simulation.h"
#include <iostream>
#include <sstream>

using namespace std;

int num = 10;

class Counter : public Process {
    void Actions() {
        while (num > 0) {
            num--;
            cout << this << ": count = " << num << endl;
            Hold(0);
        }
    }
};

void Switch() {
    Activate(new Counter);
    Activate(new Counter);

    cout << "count = " << num << endl;
    Hold(1);
    cout << "count = " << num << endl;
}

int main(int argc, char *argv[]) {
    if (argc > 1) {
        std::stringstream str;
        str << argv[1];
        str >> num;
    } 

    Simulation(Switch())

    return 0;
}
