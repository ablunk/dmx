/*
 * DBL Core
 * Copyright (C) 2013 Andreas Blunk
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <iostream>
#include <sstream>
#include <stack>
#include <vector>

//#define MEASURE_EXEC_TIME
//#define PRINT_MEM_USAGE
//#define PRINT_LOG

#include "goto-sim.cpp"

// The size of the variables area is computed by the sum of the number of bytes of each parameter and local variable defined by a function. Variables allocated memory in the variables area in the order of their appearance in the BL function. The value of a certain variable is computed from the base vbp by adding the number of bytes of all variables which are defined before the regarded variable.

// int size, int mem[size], int i, int r
#define F_varea_size sizeof(int) + sizeof(int)*128*1024/4 + sizeof(int) + sizeof(int)
#define F_S_size sizeof(int)
#define F_MEM_size sizeof(int)*128*1024/4
#define F_I_size sizeof(int)
#define F_R_size sizeof(int)

// The pointer vbp has to be interpreted as a char pointer. This allows to make use of pointer arithmetics with a given number of bytes in order to compute the address of a corresponding variable. The variable then has a certain type, so another reinterpretation of the pointer to the variable is necessary.
#define F_S  (* reinterpret_cast<int*>( (reinterpret_cast<char*>(cx->pstack.top->vbp) + 0) ))
#define F_MEM  reinterpret_cast<int*>( (reinterpret_cast<char*>(cx->pstack.top->vbp) + F_S_size) )
#define F_I (* reinterpret_cast<int*>( (reinterpret_cast<char*>(cx->pstack.top->vbp) + F_S_size + F_MEM_size) ))
#define F_R  (* reinterpret_cast<int*>( (reinterpret_cast<char*>(cx->pstack.top->vbp) + F_S_size + F_MEM_size + F_I_size) ))

// access to a return value if the last function call returned an int value
#define LRV_INT  (cx->pstack.lrv.iv)

int num = 4;
int msize = 128*1024/4;
int sum = 0;

class P : public Execution {
public:
    int n;

    P(int pid, void* cont) : Execution(pid,cont), n(0) {}
};

void simulate(int argc, char *argv[]) {
    int nextPid = 0; // next available pid
    Execution* cx; // current execution
    ml = new MovingList();

    // main Execution gets pid-0
    cx = new Execution(nextPid++, &&main_l1);
    ml->last->add(cx);

    // beginning of main
    main_l1:;

    if (argc > 1) {
        std::stringstream str;
        str << argv[1];
        str >> num;
    }

    if (argc > 2) {
        std::stringstream str2;
        str2 << argv[2];
        str2 >> msize;
    }

    ml->last->add(new P(nextPid++, &&P_actions));
    log("P created.");

    print("initial count = " << num);
    while (num > 0) {
        num--;
        
        // call f(msize)
        cx->pstack.push(&&main_l2, F_varea_size);
        F_S = msize;
        goto fn_f;
        main_l2:;
        log("f() returned with return value = " << LRV_INT);
        sum += LRV_INT;
    }
    print("final count = " << num);
    print("sum = " << sum);

    goto end_cp;

    P_actions:;
    log("action execution begins.");

    while (num > 0) {
        num--;

        // call f(msize)
        cx->pstack.push(&&P_actions_l2, F_varea_size);
        F_S = msize;
        goto fn_f;
        P_actions_l2:;
        log("f() returned with return value = " << LRV_INT);
        sum += LRV_INT;
    }

    TERMINATE;

    fn_f:;
    //int mem[TN_N]; --> F_MEM

    // init mem because SLX does so
/*    F_I = 0;
    while (F_I < F_S - 1) {
        *(F_MEM + F_I) = 0;
        F_I++;
    }*/
    memset(F_MEM,0,F_S*4);
        
    *(F_MEM + 0) = 'a';
    *(F_MEM + F_S - 1) = 'z';
    F_R = *(F_MEM + 0) + *(F_MEM + F_S - 1);
    
    cx->cont = &&fn_tn_l1;
    YIELD;
    fn_tn_l1:;
    LRV_INT = F_R;
    log("peak tn() returns with value = " << LRV_INT);

    // end of procedure m
    {
        void* rp = cx->pstack.top->returnPoint;
        cx->pstack.pop();
        goto *rp;
        //goto *( (reinterpret_cast<Frame*>(cx->pstack.top->next))->returnPoint );
    }

    // end of program
    end_cp:;
    print("reached end_cp");
}

int main(int argc, char *argv[]) {

    simulate(argc, argv);

#ifdef PRINT_MEM_USAGE
    printMemUsage();
#endif

    return 0;
}
