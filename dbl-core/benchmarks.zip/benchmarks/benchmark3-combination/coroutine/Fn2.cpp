#include "simulation.h"
#include <iostream>
#include <sstream>

using namespace std;

int num = 4;
int msize = 128*1024/4;
int sum = 0;
int n = 0;

class Counter : public Process {

    int f(int size) {
        int mem[size];

        // init mem because SLX does so
        /*int i=0;
        while (i < size-1) {
            mem[i++] = 0;
        }*/
        memset(mem,0,size*4);
        
        mem[0] = 'a';
        mem[size-1] = 'z';
        int r = mem[0] + mem[size-1];
        Hold(0);
        return r;
    }

    void Actions() {
        while (num > 0) {
            num--;
            //cout << this << ": count = " << num << endl;
            sum += f(msize);
        }
    }
};

void Switch() {
    Activate(new Counter);
    Activate(new Counter);

    cout << "count = " << num << endl;
    Hold(1);
    cout << "count = " << num << endl;

    cout << "sum = " << sum << endl;
}

int main(int argc, char *argv[]) {
    if (argc > 1) {
        std::stringstream str;
        str << argv[1];
        str >> num;
    }
    if (argc > 2) {
        std::stringstream str2;
        str2 << argv[2];
        str2 >> msize;
    } 

    Simulation(Switch());

    return 0;
}
