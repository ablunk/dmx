#include <iostream>
#include <sstream>

int pnum = 1;

int f(int n) {
    return n+1;
}

int main(int argc, char *argv[]) {
    if (argc > 1) {
        std::stringstream str;
        str << argv[1];
        str >> pnum;
    }

    int sum = 0;
    for (int i=0; i<pnum; i++) {
        sum += f(i);
    }
    std::cout << sum << std::endl;

    return 0;
}
