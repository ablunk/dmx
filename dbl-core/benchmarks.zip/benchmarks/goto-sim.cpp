/*
 * DBL Core
 * Copyright (C) 2013 Andreas Blunk
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <iostream>
#include <stack>
#include <vector>
#include <stdlib.h>

#include "measure.cpp"

#ifdef PRINT_LOG
    #define log(MSG) std::cout << "pid-" << cx->pid << ": " << MSG << std::endl;
    #define log2(MSG) std::cout << MSG << std::endl;
#else
    #define log(MSG) 
    #define log2(MSG) 
#endif

#define print(MSG) std::cout << MSG << std::endl;
#define pprint(MSG) std::cout << "pid-" << cx->pid << ": " << MSG << std::endl;

// in Byte
#define STACK_SIZE (16+4+128+4+4)*1024 //200000000
//32*1024*200

#define YIELD   log("YIELD"); \
                cx = ml->yield(); \
                goto *(cx->cont);

#define TERMINATE   log("TERMINATE"); \
                    cx = ml->terminate(); \
                    goto *(cx->cont);

class Frame {
public:
    Frame* prev; // pointer to previous stack frame
    void* returnPoint; // pointer to return label
    void* vbp; // pointer to base of variables area
    void* next; // poiner to next free address for next stack frame (after variables area)

    Frame(Frame* prev, void* returnPoint, int vsize)
        : prev(prev), returnPoint(returnPoint)
    {
        vbp = this + 1; // var area starts right behind frame object
        next = reinterpret_cast<char*>(vbp) + vsize;
    }
};

class PStack {
public:
    char mem[STACK_SIZE];
    Frame bottom; // process bottom frame, used for local variables of actions part
    Frame* top;
 
    // an active function call, which returns places its return value in the variable lrv.
    union lrv_union {
        int iv;
        double dv;
        bool bv;
        void* pv;
    } lrv;

    PStack() : bottom(NULL, NULL, 0), top(&bottom) {
        bottom.vbp = mem;
        bottom.next = mem;
    }

    // init bottom frame for local variables. must be called at beginning of actions part with necessary size.
    void init(int bsize) {
        log2("stack size: " << sizeof(mem) / 1024.0);
        bottom.vbp = mem;
        bottom.next = reinterpret_cast<char*>(bottom.vbp) + bsize;
    }

    // vsize: size of variables area in bytes
    void push(void* returnPoint, int vsize) {
        log2("old top = " << top);
        top = new(top->next) Frame(top, returnPoint, vsize);
        log2("new top = " << top);
        log2("top.prev = " << top->prev);
        log2("top.next = " << top->next);
        log2("top.vbp = " << top->vbp);
        log2("pushed stack frame");
    }

    void pop() {
        top = top->prev;
        log2("popped stack frame");
    }
};

class MovingList;

class Execution {
public:
    int pid;
    PStack pstack; // stack of this execution
    void* cont; // continuation instruction
    Execution* nextMoving; // next execution if this execution is in the moving list

    Execution(int pid, void* cont, bool createStack = true) : pid(pid), cont(cont) {
        log2("created execution " << pid);
    }

    virtual void add(Execution* e);

    // gets the moving list back into a consistent state if the first Execution is a NullExecution,
    // i.e. the moving list is essentially empty. this saves condition checks on the moving list,
    // i.e. something like "first == NULL" checks.
    virtual void repairMovingList();
};

class NullExecution : public Execution {
public:
    NullExecution() : Execution(-1, NULL) {
        nextMoving = this;
    }
    virtual void add(Execution* e);
    virtual void repairMovingList();
};

// TODO priority is missing
class MovingList {
public:
    Execution* first;
    Execution* last;
    NullExecution nullx;

public:
    MovingList() : first(&nullx), last(&nullx) {}

    Execution* yield();
    Execution* terminate(); // terminate current and return next from moving list
};

// moves the current Execution to the end and returns the new first Execution
Execution* MovingList::yield() {
    Execution* cx = first; // the current execution is the first execution in the moving list
    first = first->nextMoving;
    first->repairMovingList();
    last->add(cx); // adds the execution after the current last execution
    return first;
}

Execution* MovingList::terminate() {
    Execution* cx = first; // the current execution is the first execution in the moving list
    first = first->nextMoving;
    first->repairMovingList();
    return first;   
}

MovingList* ml;

void Execution::add(Execution* e) {
    ml->last->nextMoving = e;
    ml->last = e;
    e->nextMoving = &(ml->nullx);
}

void Execution::repairMovingList() {
    // empty
}

void NullExecution::add(Execution* e) {
    ml->first = e;
    ml->last = e;
    e->nextMoving = &(ml->nullx);
}

void NullExecution::repairMovingList() {
    ml->last = this;
}
